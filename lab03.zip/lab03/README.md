# uk.ac.nulondon:lab03

Write your project description here...

Overview
Create a new project called lab3. All the work in this lab will be done inside your main > java > uk.ac.nulondon package.

In this lab, we will cover:

ArrayLists
Introduction to Homework 2
Quiz practice problems (see below, we'll review the solutions in-lab)
ArrayLists
In lecture, we touched on the List interface. It's worth stressing that ArrayList Links to an external site.is an implementation of the List interface, and therefore shares many of the same functions. We'll go over a brief demo of some functions including:

add/remove
contains
get
isEmpty
size
Problem 1: MyList
Create a class MyList with a private data member list that is an array of ints. Write a constructor that takes in an array of ints and copies to the private data member.

Problem 2: Time
Create a class Time that has three data members: hour (int), minute (int), and second (int).

Problem 2.1: Constructors
Create two constructors:

The first constructor takes in three integers representing the hour, minute and second values and sets the data member values accordingly.
The second constructor takes in nothing and initializes every value to 0.
Problem 2.2: sameTime
Write a method sameTime that takes in an object of type Time and determines whether "this" time is the same as the given Time. You should check all three fields; do not use .equals().

Problem 3: Testing
Create a ListAndTime test file in test > java > uk.ac.nulondon. Test your constructors and sameTime method.

Submission
There is no submission for Lab 3. Going forward, we will be using labs for homework review/questions & quiz prep :)

Generated at 2024-01-30 14:06:00
